# HireSphere AI — Backend Codebase
**Lead Developer:** Sakshi Sable (PRN: SCFU224029)  
**AI NLP Lead:** Pranavi Jadhav (PRN: SCFU224040)  
**Project Guide:** Dr. Arindam Sarkar  
**University:** MIT Vishwaprayag University, Solapur  

---

## 📁 Backend Directory Structure
```
Backend-Code/
├── api/                     # 50 REST Route Handlers (.ts files)
│   ├── auth/                # Login, Register, Logout, Me, Password Reset
│   ├── ai/                  # AI matching & analysis endpoints
│   ├── applications/        # Application lifecycle (CRUD, Status, Withdraw)
│   ├── attendance/          # Clock-in, history, monthly summary
│   ├── audit-logs/          # Immutable system logs
│   ├── candidate/           # Candidate profile APIs
│   ├── dashboard/           # HR, Employee & Candidate stats
│   ├── departments/         # Department management
│   ├── employees/           # Employee lifecycle & directory
│   ├── health/              # Server health check
│   ├── jobs/                # Job requisitions CRUD
│   ├── leaves/              # Leave requests & approvals
│   ├── notifications/       # User alert stream
│   ├── performance/         # Appraisal ratings
│   ├── reports/             # Exportable analytics
│   ├── resumes/             # Secure resume upload & retrieval
│   ├── settings/            # System preferences
│   └── users/               # User administration
├── lib/                     # Backend Utilities & Security (.ts files)
│   ├── auth.ts              # Jose JWT & Bcrypt password hashing
│   ├── api.ts               # Standard API Envelope, RBAC, Rate Limiting
│   ├── db.ts                # Prisma Client Singleton
│   ├── constants.ts         # System roles, statuses & thresholds
│   ├── datetime.ts          # Timezone & date utilities
│   ├── serialize.ts         # Safe JSON serialization
│   ├── storage.ts           # Private PDF file disk storage
│   └── ai/                  # AI / NLP Matching Engine (.ts files)
│       ├── analyze-service.ts
│       ├── pdf-parser.ts
│       ├── resume-matcher.ts
│       ├── skill-dictionary.ts
│       ├── text-preprocessing.ts
│       └── tfidf.ts
├── prisma/
│   ├── schema.prisma        # 19 Relational Entities Schema
│   └── dev.db               # SQLite database file
├── scripts/
│   └── seed.ts              # Database mock seed script
├── package.json
├── tsconfig.json
└── .env
```
